const showFloatingMessage = (message, type = "info") => {
  // Remove existing message if any
  const oldMsg = document.querySelector("#gform-solver-loader");
  if (oldMsg) oldMsg.remove();

  const div = document.createElement("div");
  div.id = "gform-solver-loader";
  div.innerText = message;

  div.style.position = "fixed";
  div.style.top = "20px";
  div.style.right = "20px";
  div.style.zIndex = "9999";
  div.style.padding = "10px 16px";
  div.style.background =
    type === "success" ? "#4caf50" : type === "error" ? "#f44336" : "#333";
  div.style.color = "#fff";
  div.style.borderRadius = "8px";
  div.style.boxShadow = "0 2px 10px rgba(0,0,0,0.3)";
  div.style.fontSize = "14px";
  div.style.fontFamily = "sans-serif";

  document.body.appendChild(div);

  // Auto remove after 4 seconds
  setTimeout(() => {
    div.remove();
  }, 4000);
};

const getAnswers = async (questions) => {
  try {
    const res = await fetch("http://localhost:8000/api/get-answers", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ questions }),
    });

    const data = await res.json();
    return data.answer;
  } catch (error) {
    console.error("Error fetching answers:", error);
    showFloatingMessage("❌ Failed to fetch answers", "error");
  }
};

const autoFillForm = (answersArray) => {
  const questionCards = document.querySelectorAll(".geS5n");

  answersArray.forEach((answerObj) => {
    const matchingCard = Array.from(questionCards).find(
      (card) =>
        card.querySelector(".M7eMe")?.innerText.trim().toLowerCase() ===
        answerObj.question.toLowerCase()
    );

    if (!matchingCard) return;

    // Case 1: Multiple Choice
    const options = matchingCard.querySelectorAll(".ulDsOb");
    if (options.length > 0 && answerObj.answer) {
      options.forEach((el) => {
        const label = el.innerText.trim().toLowerCase();
        if (label === answerObj.answer.toLowerCase()) {
          el.click();
        }
      });
    }

    // Case 2: Text input
    const textInput = matchingCard.querySelector("input[type='text']");
    if (textInput && answerObj.answer) {
      textInput.focus();
      textInput.value = answerObj.answer;
      textInput.dispatchEvent(new Event("input", { bubbles: true }));
      textInput.dispatchEvent(new Event("change", { bubbles: true }));
    }
  });
};

const getQuestions = async () => {
  showFloatingMessage("🕵️ Extracting questions...");

  const questionCards = document.querySelectorAll(".geS5n");
  const questions = [];

  questionCards.forEach((card) => {
    const questionText = card.querySelector(".M7eMe")?.innerText?.trim();
    if (!questionText) return;

    const options = Array.from(card.querySelectorAll(".ulDsOb")).map((option) =>
      option.innerText.trim()
    );

    questions.push({ question: questionText, options });
  });

  showFloatingMessage("🤖 Sending to Gemini AI...");
  console.log(questions);
  const questionsWithAnswers = await getAnswers(questions);
  console.log(questionsWithAnswers);

  if (!questionsWithAnswers || !Array.isArray(questionsWithAnswers)) {
    showFloatingMessage("❌ Invalid response from Gemini", "error");
    return;
  }
  showFloatingMessage("📝 Auto-filling form...");
  autoFillForm(questionsWithAnswers);

  showFloatingMessage("✅ Form auto-filled successfully!", "success");
};

window.addEventListener("load", () => {
  setTimeout(getQuestions, 2000); // delay for full DOM load
});
