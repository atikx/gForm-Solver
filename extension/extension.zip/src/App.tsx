import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import { useState } from "react";

function App() {
  const [status, setStatus] = useState("Click the button to run the script");
  const handleClick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab?.id) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"] // must match name in /dist
    });

    setStatus("✅ Script injected!");
  } catch (err) {
    console.error("Injection failed:", err);
    setStatus("❌ Failed to inject script.");
  }
};

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
        <button onClick={handleClick} className="button">
          Click me
        </button>
      </div>
      <p className="read-the-docs">
        {status}
      </p>
    </>
  );
}

export default App;
